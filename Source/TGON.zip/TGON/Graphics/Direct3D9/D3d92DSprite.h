#pragma once
//#include <atlbase.h>
//#include <Graphics/TGraphicsDevice.h>
//
//namespace tgon
//{
//
//
//class D3d92DSprite
//{
//public:
//	D3d92DSprite( const SpTGraphicsDevice&, const wchar_t* spritePath );
//	~D3d92DSprite( );
//
//	void SetMatrix( );
//	void Render( );
//
//	virtual uint32_t GetWidth( );
//	virtual uint32_t GetHeight( );
//
//private:
//	const SpTGraphicsDevice m_gd;
//
//	CComPtr<IDirect3DTexture9> m_texture;
//	D3DXIMAGE_INFO m_imgInfo;
//};
//
//
//}