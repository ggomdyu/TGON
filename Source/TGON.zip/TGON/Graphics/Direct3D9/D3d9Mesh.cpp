#include "PrecompiledHeader.h"
#include "D3d9Mesh.h"

//#include "D3d9Util.h"
//
//tgon::D3d9Mesh::D3d9Mesh( const SpTGraphicsDevice& device, const wchar_t* meshPath ) :
//	m_mesh( LoadMesh( device->GetD3dDevice(), meshPath ))
//{
//}
//
//
//tgon::D3d9Mesh::~D3d9Mesh( )
//{
//	
//}
