/*
* Author : Junho-Cha
* Date : 04/01/2016
* Latest author :
* Latest date :
*/

#pragma once
#include "../Config/Platform.h"

#ifdef TGON_PLATFORM_WINDOWS
	#include "../Window/Windows/WindowsWindow.h"
#elif TGON_PLATFORM_ANDROID
#endif