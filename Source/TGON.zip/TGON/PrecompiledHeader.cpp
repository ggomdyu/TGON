// PrecompiledHeader.cpp : source file that includes just the standard includes
// ConsoleApplication1.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "PrecompiledHeader.h"

// TODO: reference any additional headers you need in PrecompiledHeader.h
// and not in this file
