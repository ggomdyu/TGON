#include "PrecompiledHeader.h"
#include "DefaultScene.h"

#include "../System/GraphicsSystem.h"


void DefaultScene::Update( float tickTime )
{
}

void DefaultScene::Render( )
{
}
