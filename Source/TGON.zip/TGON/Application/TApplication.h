/*
* Author : Junho-Cha
* Date : 04/02/2016
* Latest author :
* Latest date :
* Description : API Sets for cross-platform
*/


#pragma once
#include "../Platform/PlatformApplication.h"
#include "../Config/Build.h"
#include "../Config/SyntaxCompatible.h"


namespace tgon
{


class TGON_API TApplication : 
	public ApplicationImpl
{
public:
	static bool DispatchEvent( _Out_ enum struct WindowEvent* );
	static void GetScreenSize( int32_t* width, int32_t* height );
	static TSystemBatteryInfo GetPowerInfo( );

private:
	TApplication( ) = delete;
	~TApplication( ) = delete;
};


TGON_FORCEINLINE bool TApplication::DispatchEvent( _Out_ WindowEvent* wndEvent )
{
	return ApplicationImpl::DispatchEvent( wndEvent );
}

TGON_FORCEINLINE void TApplication::GetScreenSize( int32_t* width, int32_t* height )
{
	ApplicationImpl::GetScreenSize( width, height );
}

TGON_FORCEINLINE TSystemBatteryInfo TApplication::GetPowerInfo( )
{
	return ApplicationImpl::GetPowerInfo( );
}


}