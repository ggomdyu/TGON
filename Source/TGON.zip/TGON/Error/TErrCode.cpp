#include "PrecompiledHeader.h"
#include "TErrCode.h"

template<>
const char* tgon::TEnumStrings<tgon::TErrCode>::m_stringArr[] =
{
	"ID_FAILED",
	"ID_SUCCESS",
};