/*
* Author : Junho-Cha
* Date : 04/25/2016
* Latest author :
* Latest date :
*/


#pragma once
#include "../Config/Build.h"


namespace tgon
{


template<typename T>
struct TGON_API TEnumString
{
	static const char* m_errString[];
};


}