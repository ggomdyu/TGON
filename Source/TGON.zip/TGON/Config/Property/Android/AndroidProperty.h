#pragma once
#include <sdkddkver.h>

#define TGON_SUPPORT_NEON
#define TGON_SUPPORT_SIMD