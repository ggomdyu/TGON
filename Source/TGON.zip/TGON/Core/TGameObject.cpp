#include "PrecompiledHeader.h"
#include "TGameObject.h"


tgon::TGameObject::TGameObject( )
{
}

tgon::TGameObject::~TGameObject( )
{
}