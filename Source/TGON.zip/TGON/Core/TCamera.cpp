#include "PrecompiledHeader.h"
#include "TCamera.h"



const tgon::TVector3 tgon::TCamera::Eye( 0.f, 0.f, 0.f );
const tgon::TVector3 tgon::TCamera::LookAt( 0.f, 0.f, -5.f );
const tgon::TVector3 tgon::TCamera::Up( 0.f, 1.f, 0.f );


tgon::TCamera::TCamera( )
{
}


tgon::TCamera::~TCamera( )
{
}
