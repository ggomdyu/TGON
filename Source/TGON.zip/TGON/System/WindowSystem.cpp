#include "PrecompiledHeader.h"
#include "WindowSystem.h"

#include "../Console/TConsole.h"


tgon::WindowSystem::WindowSystem( )
{
	TLOG( "[CREATED] tgon::WindowSystem" );
}

tgon::WindowSystem::~WindowSystem( )
{
	TLOG( "[DESTROYED] tgon::WindowSystem" );
}