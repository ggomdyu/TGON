/*
* Author : Junho-Cha
* Date : 11/12/2015
* Latest author :
* Latest date :
*/

#pragma once
#include <stdint.h>

int32_t tgMain( int32_t argc, char* argv[] );
