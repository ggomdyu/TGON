#include "PrecompiledHeader.h"
#include "SpriteComponent.h"

tgon::SpriteComponent::SpriteComponent(
	const wchar_t* spritePath )
{
}


tgon::SpriteComponent::~SpriteComponent( )
{
}


void tgon::SpriteComponent::Update( float tickTime )
{
}

void tgon::SpriteComponent::Render( )
{
}