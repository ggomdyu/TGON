#include "PrecompiledHeader.h"
#include "IComponent.h"


tgon::IComponent::IComponent( ) :
	m_owner( nullptr )
{
}

tgon::IComponent::~IComponent( )
{
};