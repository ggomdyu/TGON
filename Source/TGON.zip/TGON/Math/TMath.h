/*
* Author : Junho-Cha
* Date : 03/14/2016
* Latest author :
* Latest date :
* Description :
*/

#pragma once
#include "../Platform/PlatformMath.h"

namespace tgon
{
	typedef MathImpl TMath;
}