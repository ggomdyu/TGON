/*
* Author : Cha Junho
* Date : 07/06/2016
* Latest author :
* Latest date :
*/

#pragma once
#include "../../Platform/Config/Build.h"


namespace tgon
{

//
//class TGON_API IComparable
//{
//public:
//	virtual void CompareTo( class TObject& ) = 0;
//};
//

}