#include "PrecompiledHeader.h"
#include "TObject.h"


tgon::TObject::TObject( )
{
}

tgon::TObject::~TObject( )
{
}
